git fetch
git pull
mvn compile
mvn exec:java -Dexec.mainClass="com.hilland.HillandCurlServer"
